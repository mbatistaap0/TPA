# programa soma

n1= float(input('digite um número: '))
n2= float(input('digite outro número: '))
s = n1 + n2
print('A soma de {} + {}= {}'.format(n1,n2,s))
