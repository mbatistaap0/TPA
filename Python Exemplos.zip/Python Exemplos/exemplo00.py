# Crie um programa que calcule a média de duas notas

print('.... Programa de média....')
n1 = float (input('digite a primeira nota: '))
n2 = float (input('digite a segunda nota'))
m = (n1 + n2) / 2
print ('A média das notas {} e {} é igual a {}.'.format(n1,n2,m))

