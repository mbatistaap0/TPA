# programa raiz
import math
n1 = float(input('Entre com o número desejado: '))
raiz = math.sqrt(n1)
print('A raíz quadrada do número {} é igual a {}'.format(n1, raiz))