from random import randint
n = (randint(1,10), randint(1,10), randint(1,10), randint(1,10), randint(1,10))
print (f'Os valores sorteados: {n}')
print(f'Maior valor: {max(n)}')
print(f'Menor valor: {min(n)}')