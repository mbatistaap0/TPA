conjunto = ('Farmacia', 'Marcenaria', 'Boutique', 'Padaria', 'Mecanica', 'Papelaria', 'Doceria', 'Restaurante', 'Bar', 'Estudio', 'Otica', 'Mercado', 'Acougue', 'Locadora', 'Banco', 'Shopping')
print('As vogais A, E, I, O e U...')
for palavra in conjunto:
    print(f'\nem {palavra}: ', end='')
    for letra in palavra:
        if letra.lower() in 'aeiou':
            print(letra, end=', ')