n = (int(input('Digite o 1° número: ')), int(input('Digite o 2° número: ')), int(input('Digite o 3° número: ')), int(input('Digite o 4° número: ')))
print(12*'-=-=')
print(f'Valores digitados: {n}')
print(f'O valor "9" apareceu {n.count(9)} vezes.')
if 3 in n:
    print(f'O valor "3" apareceu na {n.index(3)+1}ª posição.')
else:
    print('O valor "3" não foi digitado!')
print('Valores pares registrados: ', end='  ')
for par in n: 
    if par % 2 == 0:
        print(n, end='  ')