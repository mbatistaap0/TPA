# 18 - Faça um programa que insira os lados de um triângulo e informe se será:
# - EQUILÁTERO: todos os lados iguais
# - ISÓSCELES: dois lados iguais, um diferente
# - ESCALENO: todos os lados diferente

d1=float(input('Digite o lado 1 do triângulo:'))
d2=float(input('Digite o lado 2 do triângulo:'))
d3=float(input('Digite o lado 3 do triângulo:'))

if d1==d2 and d1==d3:
    print('Será equilátero')

elif d2==d3 and d2!=d1:
    print('Será Isósceles')

elif d1==d3 and d1!=d2:
    print('Será Isósceles')

elif d1==d2 and d1!=d3:
    print('Será Isósceles')
else:
    print('Será Escaleno')