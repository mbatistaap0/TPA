#exercício 8

n1= float(input('digite o valor do produto:'))
m1= n1-n1*0.07

print('o valor com o desconto será {}.'.format(m1))