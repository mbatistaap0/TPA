#Até 9 anos - Mirim
#Até 14 anos - Infantil
#Até 19 anos - Junior
#Até 25 anos - Sênior
#Acima - Master

idade= int(input('digite a idade do nadador:'))

if idade<=9:
    print('a idade {} anos se encaixa na categoria MIRIM!'.format(idade))

elif idade<10 and idade >=14:
    print('A idade {} anos se encaixa na categoria INFANTIL!'.format(idade))

elif idade<14 and idade>=19:
    print('A idade {} anos se encaixa na categoria JUNIOR!'.format(idade))

elif idade>19 and idade>=25:
    print('A idade {} anos se encaixa na categoria SÊNIOR!'.format(idade))

else:
    print('A idade {} anos se encaixa na MASTER!'.format(idade))