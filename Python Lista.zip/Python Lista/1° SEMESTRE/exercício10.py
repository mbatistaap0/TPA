#exercício10

n1= float(input('digite o grau em fahrenheit:'))
n2= (n1-32)/ 1.8

print ('o grau {} em celsius é{}.'.format(n1, n2))