d1= float(input('digite o salário:'))

if d1<1250:
    p=d1+d1*0.1
    print('o salário será: {}'.format(p))

else:
    p=d1+d1*0.15
    print('o salário será: {}'.format(p))