#Ano de nascimento

ano= float(input('Digite o ano do seu nascimento: '))
atual= float(input('Digite o ano atual: '))

if atual > ano:
    d1= atual - ano
    print('Sua idade é {}'.format(d1))


else:
    print('há algo de errado!')
