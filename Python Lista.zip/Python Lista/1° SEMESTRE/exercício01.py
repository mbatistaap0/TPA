n1 = int(input('Digite um número: '))
a = n1-1
s = n1+1
print('o antecessor do número {} é igual a {}, \n o sucessor de {} é igual a {}'.format(n1, a, n1, s))