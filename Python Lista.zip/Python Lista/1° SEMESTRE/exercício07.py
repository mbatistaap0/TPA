#exercício 7

n1= float(input('digite a largura:'))
n2= float(input('digite a altura:'))
m1= (n1*n2) / 2.3

print ('a quantidade de litros necessários será {}.'.format(m1))