# Elabore um programa que calcule o valor a ser pago por um produto, considerando o seu preço normal e condição de pagamento:
#à vista dinheiro/cheque: 10% de desconto
#à vista no cartão: 5% de desconto
#em até 2x no cartão: preço formal
#3x ou mais no cartão: 20% de juros

pagamento=int(input('Digite sua forma de pagamento: 1- a vista no dinheiro ou cheque:'
      '2-à vista no cartão'
      '3-em até 2x no cartão'
      '4-3x ou mais no cartão'))
valor=float(input('digite o valor do produto:'))

if pagamento==1:
    p= valor- (valor*0.1)
    print('o valor será {}'.format(p))

elif pagamento==2:
     d= valor - (valor*0.05)
     print('o valor será {}'.format(d))

elif pagamento==3:
    g= valor
    print('o valor será {}'.format(g))

else:
    t= valor+ (valor*0.2)
    print('o valor será {}'.format(t))
