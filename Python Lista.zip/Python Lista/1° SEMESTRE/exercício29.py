#Comerciante

produto= float(input('Digite o valor do produto:'))

if produto<=20:
    f1=(produto + produto*0.45)
    print('O valor será: {}'.format(f1))


else:
    f1=(produto + produto*0.3)
    print('O valor será: {]'.format(f1))