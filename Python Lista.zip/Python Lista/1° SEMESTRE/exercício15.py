n1=int(input('digite um número:'))
n2=int(input('digite outro número:'))

if n1>n2:
    print('O primeiro número {} é maior que {}'.format(n1, n2))

elif n1<n2:
    print('o segundo número {} é maior que {}'.format(n2, n1))

else:
    print('Não existe valor maior, os dois são iguais.')