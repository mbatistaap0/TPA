d1= float(input('digite o ano:'))

if d1 %4 == 0:
    print('o ano {} é bissexto'.format(d1))

else:
    print('o ano {} não é bissexto'.format(d1))