#exercício 03

n1= float(input('digite a primeira nota: '))
n2= float(input('digite a segunda nota:'))
n3= float(input('digite a terceira nots:'))
n4= float(input('digite a quarta nota:'))
m= (n1+n2+n3+n4) /4

print('a média das notas {}, {}, {} e {} é igual a {}'.format(n1,n2, n3, n4, m))