d1 = float(input('digite a distancia:'))


if d1<=200:
    p=d1*0.50
    print('o valor da passagem é {}'.format(p))

else:
    p=d1*0.45
    print('o valor da passagem é {}'.format(p))