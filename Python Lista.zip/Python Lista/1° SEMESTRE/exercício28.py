#desconto do INSS

salario= float(input('Digite seu salário:'))

if salario<=600:
    print('Seu salário será ISENTO')

elif salario>600 and salario>=1200:
    d1= salario - (salario*0.2)
    ns1= salario-d1
    print('O desconto do seu salário é de {}'.format(ns1))
    print('O seu salário com desconto do INSS é {}'.format(d1))

elif salario<1200 and salario>=200:
    d1= salario - (salario*0.25)
    ns1= salario-d2
    print('O desconto do seu salário é de'.format(ns1))
    print('O seu salário com desconto do INSS é {}'.format(d1))

else:
    d1= salario - (salario*0.3)
    ns1= salario - d1
    print('O desconto do seu salario é de {}'.format(ns1))
    print('O seu salário com desconto do INSS é {}'.format(d1))
