#exercício 9

n1= float(input('digite o salário:'))
m1= n1+n1*0.15

print ('o novo salário será {}.'.format(m1))