# exercício 4

n1= float(input('digite o valor em metros:'))
c1= n1*100
m1= n1*1000

print ('o valor de metros {} em centimetros será {}, \n e {} em milímetros é {}.'.format(n1, c1, n1, m1))