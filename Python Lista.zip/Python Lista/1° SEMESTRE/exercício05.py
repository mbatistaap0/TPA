# exercício 5

n1= float(input('digite o primeiro número: '))
n2= float(input('digite o segundo número: '))
n3= float(input('digite o terceiro número:'))
c1= n1*n1
d1= n2*n2
m1= n3*n3

print('o produto de {} é {}, \n de {} é {}, \n do {} é {}.'.format(n1, c1, n2, d1, n3, m1))