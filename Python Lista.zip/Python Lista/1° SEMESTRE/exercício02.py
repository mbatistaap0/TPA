# dobro, triplo e raiz quadrada
import math
n1 = float(input('Digite um número: '))
d = n1 * 2
t = n1 * 3
raiz = math.sqrt(n1)

print('O número {} tem como o dobro {}, \n o triplo é {}, \n a raiz é {}'. format(n1, d, n1, t, n1, raiz))