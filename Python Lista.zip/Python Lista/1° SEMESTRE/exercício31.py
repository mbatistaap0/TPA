#Nome, sexo e idade

nome= str(input('Digite seu nome:'))
sexo= str(input('Digite seu sexo:'))
idade= float(input('Digite sua idade:'))

if sexo=="f" or "F" and idade <25:
    print('Parabéns, ACEITA')

else:
    print('NAO ACEITA')