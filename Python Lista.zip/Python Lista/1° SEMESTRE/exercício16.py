idade=float(input('Digite seu ano de nascimento:'))


if idade<18:
    print('Você vai se alistar em breve'.format(idade))

elif idade>=18 and idade<=19:
    print('Você está na época de se alistar'.format(idade))

else:
    print('Passou do prazo de alistamento'.format(idade))