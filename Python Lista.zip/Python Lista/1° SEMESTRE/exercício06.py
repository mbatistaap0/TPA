#exercício 6

n1= float(input('digite o quanto você tem na carteira: '))
n2= float(input('digite a conotação do dólar:'))
m1= n1/n2

print('você pode comprar {} dólar(es)'.format(m1))